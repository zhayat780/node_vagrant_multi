# node_vagrant_multi
The NodeJS ToDoList application, ready for a multi-machine Vagrantfile
